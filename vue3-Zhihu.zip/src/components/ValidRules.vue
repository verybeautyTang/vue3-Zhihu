<template>
  <div>
    <!-- $attrs自定义组件无法绑定数据，可以用v-bind。其中$attrs里面有数据 -->
    <input
      v-if="tag !== 'textarea'"
      class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp"
      :value="inputRef.val"
      @blur="inputValid"
      @input="updatValue"
      v-bind="$attrs"
      :class="{'is-invalid':inputRef.error}"
      >
    <textarea
      v-else
      class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp"
      :value="inputRef.val"
      rows="5"
      @blur="inputValid"
      @input="updatValue"
      v-bind="$attrs"
      :class="{'is-invalid':inputRef.error}"
      ></textarea>
      <div id="emailHelp" class="invalid-feedback" v-show="inputRef.error">{{inputRef.message}}</div>
  </div>
</template>

<script lang="ts">
import { emitter } from './FromControl.vue'
import { defineComponent, onMounted, PropType, reactive } from 'vue'
export interface ValidRule {
  type: 'required'| 'email' | 'pwd' | 'minlen'| 'maxlen';
  message: string;
}
const emailReg = /^[A-Za-z0-9\u4e00-\u9fa5]+@[a-zA-Z0-9_-]+(\.[a-zA-Z0-9_-]+)+$/
const pwdReg = /^(?![0-9]+$)(?![a-z]+$)(?![A-Z]+$)(?!([^(0-9a-zA-Z)])+$).{6,20}$/
export type TagType = 'input' | 'textarea'
export default defineComponent({
  props: {
    rules: {
      type: Array as PropType<ValidRule[]>,
      required: true
    },
    modelValue: String,
    tag: {
      type: String as PropType<TagType>,
      default: 'input'
    }
  },
  inheritAttrs: false, // 不继承属性
  setup (props, context) {
    console.log(context.attrs);
    const inputRef = reactive({
      error: false,
      message: '',
      val: props.modelValue || ''
    })
    const inputValid = () => {
      if (props.rules) {
        const allCheck = props.rules.every(rule => {
          let passed = true
          inputRef.message = rule.message
          switch (rule.type) {
            case 'required':
              passed = inputRef.val.trim() !== ''
              break
            case 'email':
              passed = emailReg.test(inputRef.val)
              break
            case 'minlen':
              passed = inputRef.val.length < 6
              break
            case 'maxlen':
              passed = inputRef.val.length > 20
              break
            case 'pwd':
              passed = pwdReg.test(inputRef.val)
              break
            default:
              break
          }
          return passed
        })
        inputRef.error = !allCheck
        return allCheck
      }
      return true
    }
    // Vue3的v-modal 与vue2很多不同
    const updatValue = (e: KeyboardEvent) => {
      const targetValue = (e.target as HTMLInputElement).value
      inputRef.val = targetValue
      context.emit('update:modelValue', targetValue)
    }
    // 移除事件
    onMounted(() => {
      emitter.emit('create-child', inputValid)
    })
    return {
      inputRef,
      inputValid,
      updatValue
    }
  }
})
</script>
